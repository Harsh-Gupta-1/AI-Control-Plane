# Part XII — Testing Strategy, Security Architecture, Dependencies

---

## Testing Strategy

### Unit Tests (Fakes, No Docker, No LLM)

| Module | What to test | Test doubles |
|--------|-------------|--------------|
| `domain` | Model construction, enum values, serialization | None needed |
| `runtime` | Task lifecycle transitions, illegal transitions | None needed |
| `tools.dispatcher` | Validation, policy check, schema check, execution, error handling | RecordingTool, FailingTool, AllowListedPolicyGate |
| `tools.filesystem` | Path validation, sandbox command construction, result parsing | FakeSandbox |
| `tools.terminal` | Command construction, timeout propagation, result mapping | FakeSandbox |
| `tools.browser` | URL handling, download command construction, extraction bounding | FakeSandbox |
| `llm` | FakeLLMProvider returns proposals in order, exhaustion handling | FakeLLMProvider (is itself the fake) |
| `runtime.agent_loop` | Full loop with predetermined proposals, safety guards, replanning | FakeLLMProvider, FakeSandbox, RecordingTool |
| `policy` | Capability rules, ALLOW/APPROVE/BLOCK decisions, unknown capability | None needed |
| `approval` | Create request, resolve, reject, duplicate prevention, pending query | None needed |
| `verification` | Check logic with preconfigured sandbox results | FakeSandbox |
| `tracing` | Event serialization, sink writing, append order | None needed |
| `checkpoint` | Save/load/delete roundtrip, serialization fidelity | Filesystem (temp dir) |

### Integration Tests (Real Docker, No Real LLM)

| Test | Requires | What it proves |
|------|----------|---------------|
| `test_docker_sandbox.py` | Docker | Sandbox lifecycle, isolation, execution, truncation |
| `test_filesystem_docker.py` | Docker | File write/read/list/move/delete inside real container |
| `test_terminal_docker.py` | Docker | Command execution, timeout, working directory |
| `test_browser_docker.py` | Docker | Download via wget/curl, page fetch |
| `test_agent_e2e.py` | Docker | Full loop with FakeLLM + real sandbox + real tools |
| `test_ollama_provider.py` | Ollama | LLM call/response parsing (skip if unavailable) |

### Evaluation Tests (Real Docker, FakeLLM or Real LLM)

| Test | What it proves |
|------|---------------|
| Simple tasks | Basic tool usage works end-to-end |
| Multi-tool tasks | Tool composition works |
| Recovery tasks | Agent recovers from failures |
| Safety tasks | Blocked operations stay blocked |
| Approval tasks | Approval workflow works |

### Critical Rule

**Never use the real LLM for deterministic correctness tests.** FakeLLMProvider ensures tests are reproducible. Real LLM tests are supplementary integration tests that may be flaky.

---

## Security Architecture

### Host Boundary

- Docker container has `volumes=None` — no host filesystem mounts
- All tools operate via `sandbox.execute()` which runs inside the container
- Path validation rejects Windows-style paths (`C:\`, `\\`)
- Integration tests verify no host files are created
- Checkpoints are stored on host but are runtime state, not agent-accessible

### Tool Boundary

- All tool execution goes through `ToolDispatcher.dispatch()`
- `Tool._execute()` is protected — not callable from outside the dispatcher
- Tools receive `Sandbox` via constructor, never Docker client
- Tools cannot access `ToolRegistry` or `ToolDispatcher` internals

### Policy Boundary

- `PolicyGate.evaluate()` is deterministic, synchronous, side-effect-free
- The LLM never decides authorization
- Unknown capabilities default to BLOCK
- Policy is evaluated BEFORE tool resolution (blocked requests never reach tools)

### LLM Boundary

- LLM output is treated as untrusted structured proposals
- Malformed output → retry → GIVE_UP (never execute malformed)
- `reasoning` field is informational only, never used for authorization
- LLM cannot manufacture request IDs or task IDs
- LLM sees bounded context only (no internal state, no Docker config)

### Sandbox Boundary

- Docker provides process/filesystem/network namespace isolation
- No host credentials or environment variables passed to container
- Container uses bridge networking (outbound only, no host localhost access)
- All processes die when container is destroyed

### Browser Boundary

- Browser runs inside Docker container
- Downloads go to `/downloads` inside container only
- Page content extraction is bounded (50KB default)
- Navigation has timeouts

### Terminal Boundary

- Commands run inside Docker via `sandbox.execute()`
- Output is bounded by `max_output_bytes`
- Execution has timeout via `timeout` coreutils command
- Working directory is validated against allowed roots

### Resource Abuse Prevention

| Resource | Limit | Enforced by |
|----------|-------|-------------|
| stdout/stderr | `max_output_bytes` (default 1MB) | DockerSandbox stream reader |
| Execution time | `timeout_seconds` parameter | `timeout` command in container |
| Agent iterations | `max_iterations` (default 50) | AgentLoop |
| Consecutive failures | `max_consecutive_failures` (default 3) | AgentLoop |
| Repeated actions | 3 identical in a row → replan | AgentLoop |
| Page extraction | 50KB default | BrowserExtractTool |

### Approval Boundary

- APPROVE-required actions cannot execute without explicit human resolution
- Task enters WAITING_FOR_APPROVAL state and blocks
- Rejection is recorded; action is not retried automatically
- Approval is linked to specific request_id (no reuse)

### State Integrity

- LLM sees snapshots via `AgentContext`, never mutable `Task` objects
- All task mutations go through `TaskRuntime` methods
- `deepcopy` prevents reference leaks
- LLM cannot directly call `transition_task` or `record_action`

---

## Final Task State Machine

```text
PENDING
  ↓ (start planning)
PLANNING
  ↓ (plan accepted)         ↓ (planning fails)
RUNNING                    FAILED
  ↓ (tool call)
  ↓ (observation)
  ↓ (continue...)
  ↓
  ├──→ WAITING_FOR_APPROVAL (policy APPROVE)
  │       ↓ (approved)      ↓ (rejected/cancelled)
  │     RUNNING            CANCELLED
  │
  ├──→ PLANNING (replan)
  │       ↓
  │     RUNNING
  │
  ├──→ VERIFYING (LLM says COMPLETE)
  │       ↓ (verified)      ↓ (failed)
  │     COMPLETED          RUNNING (retry) or FAILED
  │
  ├──→ FAILED (give up / max iterations / unrecoverable)
  │
  └──→ CANCELLED (external cancellation)
```

---

## Dependency Plan

| Package | Milestone | Reason | Alternatives | Required? |
|---------|-----------|--------|-------------|-----------|
| `docker` (>=7.0.0) | M3 | Docker SDK for sandbox management | Docker CLI subprocess (more fragile) | Required |
| `pytest` | M1 | Test framework ergonomics | unittest (already used alongside) | Required |
| `httpx` or `urllib.request` | M6 | HTTP client for Ollama API | `requests` (heavier), stdlib `urllib` (acceptable) | One required for Ollama |
| `playwright` | M5 (optional) | Browser automation inside sandbox | `wget`/`curl` CLI (simpler, recommended for MVP) | Optional |

Total external dependencies for MVP: `docker`, `pytest`, possibly `httpx`. This is intentionally minimal.

---

## Milestone Acceptance Criteria

### M4 COMPLETE WHEN:
```
[ ] ListDirectoryTool implemented and tested
[ ] ReadFileTool implemented and tested
[ ] WriteFileTool implemented and tested
[ ] MoveFileTool implemented and tested
[ ] DeleteFileTool implemented and tested
[ ] ExecuteCommandTool implemented and tested
[ ] FakeSandbox test double created
[ ] Path validation utility created and tested
[ ] All tools use Sandbox interface (not Docker)
[ ] All tools go through ToolDispatcher
[ ] Host paths rejected by validation
[ ] Unit tests pass with FakeSandbox
[ ] Integration tests pass with Docker
[ ] No M5+ functionality introduced
```

### M5 COMPLETE WHEN:
```
[ ] Browser-capable sandbox configured (wget/curl at minimum)
[ ] BrowserNavigateTool implemented
[ ] BrowserExtractTool implemented
[ ] BrowserDownloadTool implemented
[ ] Downloads stay inside /downloads in sandbox
[ ] Page extraction is bounded
[ ] Unit tests pass
[ ] Integration tests pass with Docker
[ ] No M6+ functionality introduced
```

### M6 COMPLETE WHEN:
```
[ ] LLMProvider protocol defined
[ ] AgentContext and LLMProposal models defined
[ ] FakeLLMProvider implemented and tested
[ ] OllamaProvider implemented
[ ] Structured output parsing with retry
[ ] Provider SDK objects don't leak
[ ] Unit tests pass
[ ] Ollama integration tests pass or skip
[ ] No M7+ functionality introduced
```

### M7 COMPLETE WHEN:
```
[ ] TaskState extended (PLANNING, WAITING_FOR_APPROVAL, VERIFYING)
[ ] Transition table updated with new states
[ ] Existing tests updated for new transitions
[ ] AgentLoop implemented with plan-act-observe cycle
[ ] Loop safety guards (iterations, failures, repeats)
[ ] Context bounding
[ ] Observation recording
[ ] Replanning support
[ ] Unit tests with FakeLLM pass
[ ] E2E integration test with Docker passes
[ ] No M8+ functionality introduced
```

### M8 COMPLETE WHEN:
```
[ ] PolicyDecision extended with APPROVE
[ ] CapabilityPolicyGate implemented
[ ] ApprovalRequest/ApprovalDecision models added
[ ] ApprovalStore protocol and InMemoryApprovalStore
[ ] Dispatcher handles APPROVE → approval_required
[ ] AgentLoop handles approval pause/resume
[ ] WAITING_FOR_APPROVAL state works
[ ] Blocked action never executes (test)
[ ] Unapproved action never executes (test)
[ ] Rejected action never executes (test)
[ ] Approved action executes once (test)
[ ] Existing M2 tests still pass
[ ] No M9+ functionality introduced
```

### M9 COMPLETE WHEN:
```
[ ] VerificationCheck protocol defined
[ ] Concrete checks (file exists, content, command success)
[ ] Verification integrated into agent loop
[ ] FailureCategory enum defined
[ ] Recovery strategies implemented
[ ] CheckpointStore protocol and JsonFileCheckpointStore
[ ] Checkpoint save/load/delete works
[ ] Agent loop saves and resumes from checkpoints
[ ] Unit tests pass
[ ] Integration tests pass
[ ] No M10+ functionality introduced
```

### M10 COMPLETE WHEN:
```
[ ] TraceEvent model with all event types
[ ] TraceSink protocol and JsonFileTraceSink
[ ] Trace emission in AgentLoop
[ ] Tracing never controls execution
[ ] EvalTask model and task definitions
[ ] EvaluationRunner implemented
[ ] Evaluation report output
[ ] Unit tests for tracing pass
[ ] Evaluation suite runnable
[ ] Full traces inspectable
```

---

## Manual Validation Scenarios

### M4
- Create and read a file inside Docker via tools
- Run `echo hello` via terminal tool, verify stdout
- Attempt path traversal, verify rejection

### M5
- Download a file from a public URL into /downloads
- Verify file exists only inside sandbox

### M7
- Give fake agent a multi-step task, inspect action/observation log
- Verify loop terminates properly

### M8
- Trigger delete_file (APPROVE-required), verify task pauses
- Approve it, verify execution completes

### M9
- Kill process mid-task, restart, verify resume from checkpoint

### M10
- Inspect full JSON-lines trace file for a completed task
- Run evaluation suite, inspect summary report

---

## Failure / Recovery Matrix

| Failure | Detection | Recovery | Terminal? |
|---------|-----------|----------|-----------|
| Tool timeout | `SandboxResult.timed_out` | Retry (1x) | No |
| Malformed LLM output | JSON parse failure | Retry (2x) then GIVE_UP | Yes after retries |
| Docker failure | `SandboxError` | Retry (1x) | Yes if persistent |
| Policy BLOCK | `ToolResult.error.code == "policy_blocked"` | Inform LLM, choose different approach | No |
| Approval rejection | `ApprovalDecision.approved == False` | Inform LLM, choose different approach | No |
| Verification failure | `VerificationResult.status == FAILED` | Replan (2x) | Yes after retries |
| Repeated action loop | Same ToolRequest 3x | Force replan | Yes after replan fails |
| Max iterations | `iteration >= max_iterations` | Abort | Yes |
| Command failure | `SandboxResult.exit_code != 0` | Retry (2x) then replan | No |

---

## Post-M10 Extension Points

The M10 architecture leaves room for future capabilities without implementation:

- **Long-running agents**: AgentLoop.run() could be made async; checkpoint store enables persistence across restarts
- **Richer permissions**: CapabilityPolicyGate rules dict is extensible; new capabilities can be added without architectural changes
- **Multi-agent**: Multiple AgentLoop instances could share a TaskRuntime; tasks already have unique IDs
- **Sandbox snapshots**: Sandbox ABC could add `snapshot()`/`restore()` methods; DockerSandbox would implement via docker commit
- **Advanced evaluation**: EvalTask definitions are data-driven; new categories can be added
- **Richer approval**: ApprovalStore protocol is extensible; could add web UI, Slack integration
- **Persistent traces**: TraceSink protocol could have database-backed implementations
- **Alternative sandboxes**: Sandbox ABC allows swapping Docker for any isolation technology

None of these require rewriting the M10 architecture. They are additive.

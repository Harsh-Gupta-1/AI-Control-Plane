# Part V — M6: LLM Abstraction

## Problem

The agent loop (M7) needs an LLM to propose plans and tool requests. The LLM must be replaceable — the architecture must not be coupled to any specific model, vendor, or SDK.

## LLM Interface

```python
# src/control_plane/llm/contracts.py

from dataclasses import dataclass, field
from typing import Protocol
from control_plane.domain import ToolRequest


@dataclass
class AgentContext:
    """Bounded structured context provided to the LLM."""
    task_goal: str
    plan_summary: str | None = None
    current_step: str | None = None
    completed_actions: list[dict] = field(default_factory=list)  # bounded history
    recent_observations: list[dict] = field(default_factory=list)  # bounded
    available_tools: list[dict] = field(default_factory=list)  # tool schemas
    error_context: str | None = None  # if replanning after failure


@dataclass
class LLMProposal:
    """Structured output from the LLM."""
    action: ProposalAction
    tool_request: ToolRequest | None = None  # if action is TOOL_CALL
    plan_steps: list[str] | None = None  # if action is PLAN
    reasoning: str = ""  # brief explanation (not used for authorization)
    completion_reason: str | None = None  # if action is COMPLETE


class ProposalAction(str, Enum):
    """What the LLM proposes to do next."""
    PLAN = "plan"           # Propose a new plan
    TOOL_CALL = "tool_call" # Propose a specific tool invocation
    COMPLETE = "complete"   # Declare the task complete
    GIVE_UP = "give_up"     # Cannot complete the task


class LLMProvider(Protocol):
    """Provider-neutral interface for LLM interaction."""
    
    def propose(self, context: AgentContext) -> LLMProposal:
        """Given bounded task context, return a structured proposal.
        
        Raises LLMError on provider failure.
        """
        ...


class LLMError(Exception):
    """Base exception for LLM provider failures."""
```

## Proposal Model

The LLM returns an `LLMProposal`, which is one of:

1. **PLAN**: A list of high-level step descriptions. The runtime records these as `PlanStep` objects.
2. **TOOL_CALL**: A specific `ToolRequest` with tool_name, capability, and arguments. The runtime validates and dispatches it.
3. **COMPLETE**: The LLM believes the task is done. The runtime must independently verify (M9).
4. **GIVE_UP**: The LLM cannot proceed. The runtime marks the task as failed.

Raw model text never becomes executable instructions. The `reasoning` field is informational only.

## Provider Abstraction

### FakeLLMProvider

```python
# src/control_plane/llm/fake_provider.py

class FakeLLMProvider:
    """Deterministic provider for testing the agent loop."""
    
    def __init__(self, proposals: list[LLMProposal]) -> None:
        self._proposals = list(proposals)
        self._call_count = 0
    
    def propose(self, context: AgentContext) -> LLMProposal:
        if self._call_count >= len(self._proposals):
            return LLMProposal(action=ProposalAction.GIVE_UP, reasoning="no more proposals")
        proposal = self._proposals[self._call_count]
        self._call_count += 1
        return proposal
```

### OllamaProvider

```python
# src/control_plane/llm/ollama_provider.py

class OllamaProvider:
    """Local Ollama adapter implementing LLMProvider."""
    
    def __init__(self, model: str = "qwen2.5:7b", base_url: str = "http://localhost:11434") -> None:
        self._model = model
        self._base_url = base_url
    
    def propose(self, context: AgentContext) -> LLMProposal:
        """Send context to Ollama, parse structured response, return proposal."""
        ...
```

The Ollama adapter:
1. Formats `AgentContext` into a system+user prompt
2. Sends HTTP POST to `{base_url}/api/chat` or `/api/generate`
3. Parses JSON response into `LLMProposal`
4. Handles malformed responses by returning a GIVE_UP proposal with error info
5. Uses Python's `urllib.request` or `httpx` — keep the dependency minimal

Provider-specific SDK objects (HTTP responses, model configs) must NOT escape into the control plane.

## Structured Output Handling

The Ollama adapter must:

1. **System prompt**: Instruct the model to respond in a specific JSON schema
2. **Schema validation**: Parse response JSON and validate required fields
3. **Malformed responses**: If the model returns unparseable output, retry once. If still malformed, return `LLMProposal(action=ProposalAction.GIVE_UP, reasoning="malformed model output")`
4. **Provider failures**: Network errors, timeouts → raise `LLMError`
5. **Token/context limits**: The `AgentContext` is pre-bounded by the runtime. The provider does not need to manage context windows.
6. **Max retries**: 2 retries for malformed output, then give up

## Model Configuration

```python
@dataclass
class LLMConfig:
    """Configuration for an LLM provider."""
    provider: str  # "fake", "ollama"
    model: str = "qwen2.5:7b"
    base_url: str = "http://localhost:11434"
    temperature: float = 0.1
    max_retries: int = 2
```

This is a simple dataclass, not a framework. The composition root reads it and constructs the appropriate provider.

## Tests

### Unit Tests (`tests/unit/test_llm_contracts.py`)
- FakeLLMProvider returns proposals in sequence
- FakeLLMProvider returns GIVE_UP when exhausted
- AgentContext serialization is complete
- LLMProposal with TOOL_CALL contains valid ToolRequest
- LLMProposal with PLAN contains step list
- ProposalAction enum values

### Integration Tests (`tests/integration/test_ollama_provider.py`)
Require Ollama running locally:
- Send a simple context, get a parseable proposal
- Handle malformed response gracefully
- Handle connection failure gracefully
- Skip if Ollama is not available

## Completion Criteria

```
[ ] LLMProvider protocol defined
[ ] AgentContext model defined
[ ] LLMProposal model defined with ProposalAction enum
[ ] FakeLLMProvider implemented and tested
[ ] OllamaProvider implemented
[ ] Structured output parsing with validation
[ ] Malformed response handling (retry + give up)
[ ] Provider failure handling (LLMError)
[ ] No provider SDK objects leak into runtime/domain
[ ] Unit tests pass
[ ] Integration tests pass or skip gracefully
[ ] No M7+ functionality introduced
```

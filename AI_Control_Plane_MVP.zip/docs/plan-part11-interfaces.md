# Part XI — Exact Interface Specifications

## Tool (existing, unchanged)

```python
class Tool(ABC):
    @property
    @abstractmethod
    def metadata(self) -> ToolMetadata: ...
    
    @abstractmethod
    def _execute(self, request: ToolRequest) -> ToolResult: ...
```

- **Ownership**: `tools.contracts`
- **Dependencies**: `domain` (ToolRequest, ToolResult)
- **Invariant**: `_execute` is only called by `ToolDispatcher`. No public execution path.

## Sandbox (existing, unchanged)

```python
class Sandbox(ABC):
    @property
    @abstractmethod
    def id(self) -> str: ...
    
    @abstractmethod
    def start(self) -> None: ...
    
    @abstractmethod
    def stop(self) -> None: ...
    
    @abstractmethod
    def destroy(self) -> None: ...
    
    @abstractmethod
    def inspect(self) -> SandboxState: ...
    
    @abstractmethod
    def execute(self, command: list[str], timeout_seconds: int, max_output_bytes: int = 1048576) -> SandboxResult: ...
```

- **Ownership**: `sandbox.contracts`
- **Dependencies**: None (pure abstract)
- **Invariant**: No Docker types exposed. Tools call only this interface.

## ToolDispatcher (extended in M8)

```python
class ToolDispatcher:
    def __init__(self, registry: ToolRegistry, policy_gate: PolicyGate) -> None: ...
    
    def dispatch(self, request: ToolRequest, approved_request_id: str | None = None) -> ToolResult: ...
```

- **Ownership**: `tools.dispatcher`
- **Dependencies**: `domain`, `policy`, `tools.registry`, `tools.contracts`
- **M8 change**: Add optional `approved_request_id` parameter. When provided and policy returns APPROVE, proceed with execution.

## PolicyGate (extended in M8)

```python
class PolicyGate(Protocol):
    def evaluate(self, request: ToolRequest) -> PolicyResult: ...
```

Unchanged protocol. New implementation `CapabilityPolicyGate` in M8.

```python
class PolicyDecision(str, Enum):
    ALLOW = "allow"
    APPROVE = "approve"   # NEW in M8
    BLOCK = "block"

class PolicyResult:
    decision: PolicyDecision
    reason: str
```

## LLMProvider (new in M6)

```python
class LLMProvider(Protocol):
    def propose(self, context: AgentContext) -> LLMProposal: ...
```

- **Ownership**: `llm.contracts`
- **Dependencies**: `domain` (ToolRequest for proposals)
- **Invariant**: Provider SDK objects never escape. Proposals are domain objects.

## AgentContext (new in M6)

```python
@dataclass
class AgentContext:
    task_goal: str
    plan_summary: str | None = None
    current_step: str | None = None
    completed_actions: list[dict] = field(default_factory=list)
    recent_observations: list[dict] = field(default_factory=list)
    available_tools: list[dict] = field(default_factory=list)
    error_context: str | None = None
```

- **Ownership**: `llm.contracts`
- **Invariant**: Pre-bounded by runtime. No unbounded data.

## LLMProposal (new in M6)

```python
@dataclass
class LLMProposal:
    action: ProposalAction
    tool_request: ToolRequest | None = None
    plan_steps: list[str] | None = None
    reasoning: str = ""
    completion_reason: str | None = None
```

## AgentLoop (new in M7)

```python
class AgentLoop:
    def __init__(
        self,
        runtime: TaskRuntime,
        dispatcher: ToolDispatcher,
        llm: LLMProvider,
        max_iterations: int = 50,
        max_consecutive_failures: int = 3,
        approval_store: ApprovalStore | None = None,  # M8
        verification_checks: list[VerificationCheck] | None = None,  # M9
        checkpoint_store: CheckpointStore | None = None,  # M9
        trace_sink: TraceSink | None = None,  # M10
    ) -> None: ...
    
    def run(self, task_id: str) -> Task: ...
    def resume(self, task_id: str) -> Task: ...  # M9
```

- **Ownership**: `runtime.agent_loop`
- **Dependencies**: `domain`, `runtime`, `tools.dispatcher`, `llm.contracts`, `approval.contracts` (M8), `verification.contracts` (M9), `tracing.contracts` (M10)
- **Forbidden**: Direct Docker imports, sandbox implementation details
- **Invariant**: All tool execution goes through dispatcher. Loop has safety guards.

## ApprovalStore (new in M8)

```python
class ApprovalStore(Protocol):
    def create_request(self, request: ApprovalRequest) -> ApprovalRequest: ...
    def get_request(self, approval_id: str) -> ApprovalRequest: ...
    def resolve(self, decision: ApprovalDecision) -> ApprovalRequest: ...
    def get_pending_for_task(self, task_id: str) -> list[ApprovalRequest]: ...
```

## VerificationCheck (new in M9)

```python
class VerificationCheck(Protocol):
    def verify(self, sandbox: Sandbox, criteria: dict[str, Any]) -> VerificationResult: ...
```

## CheckpointStore (new in M9)

```python
class CheckpointStore(Protocol):
    def save(self, task_id: str, checkpoint: TaskCheckpoint) -> None: ...
    def load(self, task_id: str) -> TaskCheckpoint | None: ...
    def delete(self, task_id: str) -> None: ...
```

## TraceSink (new in M10)

```python
class TraceSink(Protocol):
    def emit(self, event: TraceEvent) -> None: ...
```

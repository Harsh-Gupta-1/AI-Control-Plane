# Part VII — M8: Full Policy + Human Approval

## Problem

M2's `AllowListedPolicyGate` only supports ALLOW/BLOCK. M8 expands this to the full ALLOW/APPROVE/BLOCK model with capability-based rules and a human approval workflow.

## Policy Model

### Extended PolicyDecision

```python
class PolicyDecision(str, Enum):
    ALLOW = "allow"       # Execute immediately
    APPROVE = "approve"   # Requires human approval before execution
    BLOCK = "block"       # Never execute
```

### Capability Classification

```python
POLICY_RULES: dict[str, PolicyDecision] = {
    # Filesystem
    "filesystem.read": PolicyDecision.ALLOW,
    "filesystem.write": PolicyDecision.APPROVE,
    "filesystem.delete": PolicyDecision.APPROVE,
    
    # Terminal
    "terminal.execute": PolicyDecision.APPROVE,
    
    # Browser
    "browser.navigate": PolicyDecision.ALLOW,
    "browser.interact": PolicyDecision.APPROVE,
    "browser.read": PolicyDecision.ALLOW,
    "browser.download": PolicyDecision.APPROVE,
}
```

Default for unknown capabilities: BLOCK.

### CapabilityPolicyGate

```python
# src/control_plane/policy/gate.py

class CapabilityPolicyGate:
    """Full capability-based policy evaluation."""
    
    def __init__(self, rules: dict[str, PolicyDecision] | None = None) -> None:
        self._rules = rules or dict(POLICY_RULES)
    
    def evaluate(self, request: ToolRequest) -> PolicyResult:
        decision = self._rules.get(request.capability, PolicyDecision.BLOCK)
        return PolicyResult(
            decision=decision,
            reason=f"capability '{request.capability}' is {decision.value}",
        )
```

This is deterministic, synchronous, and side-effect-free. The LLM never decides authorization.

## Approval Workflow

### Domain Models

```python
# src/control_plane/domain/models.py (additions)

class ApprovalStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"

@dataclass
class ApprovalRequest:
    approval_id: str
    task_id: str
    request_id: str  # links to ToolRequest.request_id
    tool_name: str
    capability: str
    arguments: dict[str, Any]
    reason: str  # why approval is needed
    status: ApprovalStatus = ApprovalStatus.PENDING
    created_at: datetime | None = None
    resolved_at: datetime | None = None
    resolved_by: str | None = None  # "human", "timeout"

@dataclass
class ApprovalDecision:
    approval_id: str
    approved: bool
    reason: str = ""
```

### Approval Interface

```python
# src/control_plane/approval/contracts.py

class ApprovalStore(Protocol):
    def create_request(self, request: ApprovalRequest) -> ApprovalRequest: ...
    def get_request(self, approval_id: str) -> ApprovalRequest: ...
    def resolve(self, decision: ApprovalDecision) -> ApprovalRequest: ...
    def get_pending_for_task(self, task_id: str) -> list[ApprovalRequest]: ...
```

### In-Memory Approval Store

```python
# src/control_plane/approval/in_memory.py

class InMemoryApprovalStore:
    """Simple in-memory approval store for the MVP."""
    def __init__(self) -> None:
        self._requests: dict[str, ApprovalRequest] = {}
    # ... implements ApprovalStore protocol
```

## Dispatcher Integration

Update `ToolDispatcher.dispatch()` to handle APPROVE:

```python
policy_result = self._policy_gate.evaluate(request)

if policy_result.decision is PolicyDecision.BLOCK:
    return ToolResult.failure(...)

if policy_result.decision is PolicyDecision.APPROVE:
    return ToolResult.failure(
        request.request_id,
        ToolResultStatus.BLOCKED,  # reuse BLOCKED status
        "approval_required",
        policy_result.reason,
    )
```

The dispatcher does NOT handle the approval workflow itself. It returns a structured result indicating approval is required. The **agent loop** (M7's `AgentLoop`) detects `approval_required` and:

1. Creates an `ApprovalRequest` via the `ApprovalStore`
2. Transitions task to `WAITING_FOR_APPROVAL`
3. Waits for human resolution
4. On approval: transitions back to RUNNING, re-dispatches the original request with policy override
5. On rejection: records rejection, continues loop (LLM will see the rejection)

### Policy Override for Approved Requests

Add an optional `approved_request_id` parameter to `dispatch()`:

```python
def dispatch(self, request: ToolRequest, approved_request_id: str | None = None) -> ToolResult:
    # ... validation ...
    policy_result = self._policy_gate.evaluate(request)
    
    if policy_result.decision is PolicyDecision.APPROVE:
        if approved_request_id is None:
            return ToolResult.failure(..., "approval_required", ...)
        # Verified: this request was explicitly approved
    
    if policy_result.decision is PolicyDecision.BLOCK:
        return ToolResult.failure(...)
    
    # ... proceed with execution ...
```

## Agent Loop Integration

```python
# In AgentLoop.run():

result = self._dispatcher.dispatch(tool_request)

if result.error and result.error.code == "approval_required":
    # Create approval request
    approval = self._approval_store.create_request(ApprovalRequest(
        approval_id=str(uuid4()),
        task_id=task_id,
        request_id=tool_request.request_id,
        tool_name=tool_request.tool_name,
        capability=tool_request.capability,
        arguments=tool_request.arguments,
        reason=result.error.message,
    ))
    
    # Transition to waiting
    self._runtime.transition_task(task_id, TaskState.WAITING_FOR_APPROVAL)
    
    # Wait for resolution (blocking for MVP; could be async later)
    decision = self._wait_for_approval(approval.approval_id)
    
    if decision.approved:
        self._runtime.transition_task(task_id, TaskState.RUNNING)
        result = self._dispatcher.dispatch(tool_request, approved_request_id=approval.approval_id)
    else:
        self._runtime.transition_task(task_id, TaskState.RUNNING)
        # Record rejection as observation, continue loop
```

For the MVP, `_wait_for_approval` can be a simple polling loop or synchronous callback. The approval is resolved externally (e.g., via a CLI prompt or test code calling `approval_store.resolve()`).

## Security Tests

```
[ ] Blocked action never executes (existing M2 test, verify still passes)
[ ] APPROVE-required action does not execute without approval
[ ] APPROVE-required action does not execute after rejection
[ ] APPROVE-required action executes exactly once after approval
[ ] Unknown capability is BLOCKED by default
[ ] Duplicate approval for same request is rejected
[ ] Task state is WAITING_FOR_APPROVAL while pending
[ ] Task transitions back to RUNNING after resolution
```

## Completion Criteria

```
[ ] PolicyDecision extended with APPROVE
[ ] CapabilityPolicyGate implemented with configurable rules
[ ] ApprovalRequest and ApprovalDecision domain models added
[ ] ApprovalStore protocol defined
[ ] InMemoryApprovalStore implemented
[ ] Dispatcher handles APPROVE → approval_required result
[ ] AgentLoop handles approval workflow
[ ] Task state WAITING_FOR_APPROVAL works correctly
[ ] Negative security tests prove blocked/unapproved actions never execute
[ ] AllowListedPolicyGate still works (backward compatible)
[ ] Existing M2 tests still pass
[ ] No M9+ functionality introduced
```

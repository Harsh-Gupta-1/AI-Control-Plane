# Part XIII — Instructions for Gemini 3.1 Pro

You are the **implementation engineer** for the AI Computer Control Plane project. You are NOT the architect. The architecture has been designed for you. Your job is to follow the implementation plan precisely.

## Before Starting Any Work

1. Read `AGENTS.md` (project root)
2. Read `docs/architecture.md`
3. Read `docs/mvp.md`
4. Read `docs/implementation-plan.md` (the master index)
5. Read all plan parts (`docs/plan-part01-audit.md` through `docs/plan-part12-testing-security-deps.md`)
6. Inspect every existing source file under `src/` and every test under `tests/`

## Implementation Rules

1. **Implement one incremental step at a time.** Follow the order in `docs/plan-part10-incremental-steps.md` exactly: M4.1, M4.2, M4.3, M4.4, M4.5, M5.1, M5.2, M5.3, M6.1, M6.2, M7.1, M7.2, M7.3, M7.4, M8.1, M8.2, M8.3, M9.1, M9.2, M9.3, M10.1, M10.2, M10.3.

2. **Do not skip steps.** Each step builds on the previous one.

3. **Do not invent major architecture.** Follow the interfaces specified in `docs/plan-part11-interfaces.md`. If you believe a change is needed, explain why before making it.

4. **Run tests after every step.** Execute `pytest` after every implementation step. All tests must pass before proceeding.

5. **Never implement future milestones early.** Do not add M5 code during M4. Do not add M7 code during M6.

6. **Never bypass the dispatcher.** All tool execution must go through `ToolDispatcher.dispatch()`.

7. **Never access the host filesystem from tools.** Tools use `sandbox.execute()`. Period.

8. **Never allow the LLM direct execution authority.** LLM proposals are validated by the runtime before dispatch.

9. **Never add dependencies without justification.** If you add a package to `pyproject.toml`, explain why in your report.

10. **Update `docs/architecture.md` when specified.** Only update it if a change genuinely affects boundaries, interfaces, or security assumptions.

## At Every Milestone Boundary

At the end of each milestone (M4, M5, M6, M7, M8, M9, M10), you MUST:

1. **Run the complete test suite**: `pytest`
2. **Run `git status` and `git diff --stat`**
3. **Stop and ask the user to commit**, providing a single-line commit message
4. **Perform a self-review** reporting:
   - Files created/modified
   - Interfaces reused from earlier milestones
   - Tests added and exact results
   - Any deviations from the plan
   - Security assumptions
   - Technical debt introduced
   - Whether the milestone acceptance criteria (from `docs/plan-part12-testing-security-deps.md`) are fully met
5. **Do NOT proceed to the next milestone** until the user confirms

## Commit Messages (Use These Exact Messages)

- After M4: `feat: implement M4 filesystem and terminal tools with sandbox integration`
- After M5: `feat: implement M5 browser tools with sandboxed download capability`
- After M6: `feat: implement M6 LLM abstraction with fake and Ollama providers`
- After M7: `feat: implement M7 agent execution loop with plan-act-observe cycle`
- After M8: `feat: implement M8 capability policy rules and human approval workflow`
- After M9: `feat: implement M9 verification checks, recovery strategies, and checkpointing`
- After M10: `feat: implement M10 execution tracing and controlled evaluation suite`

## What You Must NOT Do

- Do not redesign existing M0-M3 architecture unless you find a concrete correctness bug
- Do not introduce microservices, Kafka, Redis, databases, or distributed infrastructure
- Do not add RAG, vector databases, or ML training capabilities
- Do not build a coding assistant, browser automation framework, or Docker management tool
- Do not add multiple LLMs or multi-agent capabilities before M10
- Do not use dependency injection frameworks
- Do not create unnecessary base classes or factory patterns
- Do not optimize for number of files or classes — optimize for clear boundaries
- Do not implement post-M10 functionality

## If You Are Stuck

If the plan is ambiguous or you discover a genuine incompatibility:
1. Describe the problem clearly
2. Propose the minimal fix
3. Ask the user before making architectural changes
4. Do not silently deviate from the plan

## Virtual Environment

The project uses a Python virtual environment at `.venv/`. Run all commands through `.venv\Scripts\pytest` (Windows) or activate the venv first.

## Docker

Docker Desktop must be running for integration tests. If Docker is unavailable, integration tests should skip gracefully. Never fake Docker for isolation tests.

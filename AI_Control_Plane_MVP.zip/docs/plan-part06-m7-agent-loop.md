# Part VI — M7: Agent Execution Loop

## Problem

This is the most important milestone. It connects the LLM (M6), the dispatcher (M2), the sandbox (M3), and the tools (M4/M5) into an autonomous action-observation loop governed by the runtime (M1).

## Core Loop

```text
1. Goal received
2. Create task (PENDING)
3. Transition to PLANNING
4. Ask LLM to propose a plan
5. Record plan
6. Transition to RUNNING
7. Ask LLM to propose next action
8. If TOOL_CALL:
   a. Validate ToolRequest
   b. Dispatch through ToolDispatcher (policy → tool → sandbox)
   c. Record ToolResult as observation
   d. Update state
   e. Go to 7
9. If PLAN (replan):
   a. Record new plan
   b. Go to 7
10. If COMPLETE:
    a. Transition to VERIFYING (stub in M7, real in M9)
    b. Transition to COMPLETED
11. If GIVE_UP:
    a. Transition to FAILED
```

## Extended Task State

Add new states to `TaskState`:

```python
class TaskState(str, Enum):
    PENDING = "pending"
    PLANNING = "planning"           # NEW
    RUNNING = "running"
    WAITING_FOR_APPROVAL = "waiting_for_approval"  # NEW (used in M8)
    VERIFYING = "verifying"         # NEW (used in M9)
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
```

Extended transition table:

```python
_ALLOWED_TRANSITIONS = {
    TaskState.PENDING: frozenset({TaskState.PLANNING, TaskState.CANCELLED}),
    TaskState.PLANNING: frozenset({TaskState.RUNNING, TaskState.FAILED, TaskState.CANCELLED}),
    TaskState.RUNNING: frozenset({
        TaskState.COMPLETED, TaskState.FAILED, TaskState.CANCELLED,
        TaskState.WAITING_FOR_APPROVAL, TaskState.VERIFYING,
        TaskState.PLANNING,  # replan
    }),
    TaskState.WAITING_FOR_APPROVAL: frozenset({TaskState.RUNNING, TaskState.CANCELLED}),
    TaskState.VERIFYING: frozenset({TaskState.COMPLETED, TaskState.FAILED, TaskState.RUNNING}),
    TaskState.COMPLETED: frozenset(),
    TaskState.FAILED: frozenset(),
    TaskState.CANCELLED: frozenset(),
}
```

**Important**: Update existing unit tests that verify transitions to accommodate the new states. The existing `PENDING→RUNNING` transition becomes `PENDING→PLANNING→RUNNING`.

## Agent State — What the LLM Sees

The runtime constructs an `AgentContext` for each LLM call:

- `task_goal`: The original goal string
- `plan_summary`: Current plan steps (if any)
- `current_step`: What the plan says to do next
- `completed_actions`: Last N actions with their results (bounded, e.g., last 10)
- `recent_observations`: Last N observations (bounded, e.g., last 5)
- `available_tools`: Tool metadata schemas from the registry
- `error_context`: If replanning after failure, what went wrong

The LLM does NOT see:
- Task IDs
- Internal state machine details
- Docker configuration
- Policy rules
- Host filesystem information
- Raw sandbox objects

## Planning

```python
@dataclass
class Plan:
    steps: list[PlanStep] = field(default_factory=list)
    current_step_index: int = 0  # NEW: track progress
```

Add `current_step_index` to `Plan`. When a step completes, increment. When replanning, create a new `Plan`.

## Agent Loop Implementation

```python
# src/control_plane/runtime/agent_loop.py

class AgentLoop:
    """Drives the plan-act-observe loop with deterministic governance."""
    
    def __init__(
        self,
        runtime: TaskRuntime,
        dispatcher: ToolDispatcher,
        llm: LLMProvider,
        max_iterations: int = 50,
        max_consecutive_failures: int = 3,
    ) -> None:
        self._runtime = runtime
        self._dispatcher = dispatcher
        self._llm = llm
        self._max_iterations = max_iterations
        self._max_consecutive_failures = max_consecutive_failures
    
    def run(self, task_id: str) -> Task:
        """Execute the agent loop for a task until completion or failure."""
        ...
```

### Loop Safety Guards

1. **Max iterations**: Hard limit (default 50). After this, transition to FAILED with reason "exceeded maximum iterations".
2. **Max consecutive failures**: If the last N tool calls all fail, transition to FAILED or replan. Default 3.
3. **Identical action detection**: If the LLM proposes the exact same ToolRequest twice in a row (same tool, same args), increment a repeat counter. After 3 repeats, force replan or fail.
4. **Context bounding**: Only the last N actions/observations are included in AgentContext. Older entries are summarized or dropped.

## Observation Handling

After each tool execution:

```python
result = dispatcher.dispatch(tool_request)

observation = Observation(
    observation_id=str(uuid4()),
    source=f"tool:{tool_request.tool_name}",
    content=_summarize_result(result),  # bounded text summary
    data={
        "request_id": result.request_id,
        "status": result.status.value,
        "output": result.output,  # already bounded by sandbox
    },
)
runtime.record_observation(task_id, observation)
```

The `_summarize_result` function creates a brief human-readable summary (e.g., "read_file succeeded: 1024 bytes from /workspace/data.csv"). This is what the LLM sees in `recent_observations`.

## Replanning

Replanning occurs when:
- A tool call fails and consecutive failure count exceeds threshold
- The LLM explicitly proposes `ProposalAction.PLAN`
- Verification fails (M9)

On replan:
1. Transition task to PLANNING
2. Include failure context in `AgentContext.error_context`
3. Ask LLM for new plan
4. Replace task plan
5. Transition back to RUNNING

## Loop Termination States

| LLM Proposal | Runtime Action | Final State |
|--------------|---------------|-------------|
| COMPLETE | Verify (stub: always pass in M7) | COMPLETED |
| GIVE_UP | Record reason | FAILED |
| TOOL_CALL (max iterations) | Record reason | FAILED |
| TOOL_CALL (repeated failures) | Replan or FAILED | PLANNING or FAILED |

## Tests

### Unit Tests (`tests/unit/test_agent_loop.py`)

Use `FakeLLMProvider` with predetermined proposals:

1. **Simple completion**: PLAN → TOOL_CALL → COMPLETE → verify task COMPLETED
2. **Multi-step**: PLAN → TOOL_CALL → TOOL_CALL → TOOL_CALL → COMPLETE
3. **Replan on failure**: PLAN → TOOL_CALL(fails) → TOOL_CALL(fails) → TOOL_CALL(fails) → PLAN(replan) → TOOL_CALL(succeeds) → COMPLETE
4. **Give up**: PLAN → GIVE_UP → verify task FAILED
5. **Max iterations**: 51 TOOL_CALLs → verify task FAILED with iteration limit reason
6. **Repeated action detection**: Same TOOL_CALL 3 times → replan or fail

Use `FakeSandbox` + `RecordingTool` with the dispatcher for deterministic behavior.

### Integration Tests (`tests/integration/test_agent_e2e.py`)

With Docker + FakeLLMProvider:
- Goal: "Create a file at /workspace/hello.txt containing 'Hello World'"
- FakeLLM proposes: PLAN → write_file tool call → read_file tool call (verify) → COMPLETE
- Verify file actually exists inside sandbox
- Verify task state is COMPLETED

## Completion Criteria

```
[ ] TaskState extended with PLANNING, WAITING_FOR_APPROVAL, VERIFYING
[ ] Transition table updated
[ ] Existing runtime tests updated for new states
[ ] AgentLoop implemented with plan-act-observe cycle
[ ] Loop safety: max iterations, consecutive failures, repeated actions
[ ] Context bounding implemented
[ ] Observation recording from tool results
[ ] Replanning support
[ ] FakeLLMProvider-based deterministic tests
[ ] E2E integration test with Docker
[ ] No M8+ functionality introduced (approval is stubbed)
```

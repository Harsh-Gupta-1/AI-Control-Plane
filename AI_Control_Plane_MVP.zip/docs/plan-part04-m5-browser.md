# Part IV — M5: Browser Capability

## Problem

The agent needs to interact with web content: navigate to URLs, click elements, type into forms, extract page content, and download files. The browser must run entirely inside the Docker sandbox.

## Browser Architecture

The browser runs inside the Docker sandbox container using a headless Chromium instance. The tool communicates with it via Playwright (Python) running inside the container.

```text
BrowserTool (host-side, in tools/)
    ↓ sandbox.execute(...)
DockerSandbox
    ↓ exec inside container
Playwright + Chromium (inside container)
    ↓
Web
```

**Key decision**: Playwright and Chromium must be installed inside the Docker image. This means M5 requires a custom Dockerfile or an image-setup step. The simplest approach:

1. Create a `Dockerfile` in the project that extends `ubuntu:22.04` with Playwright and Chromium installed
2. Build this image once and use it as the sandbox image
3. Keep the Dockerfile minimal — only what's needed for the sandbox tools

Alternative (simpler, recommended for MVP): Use Playwright's CLI inside the sandbox to run browser operations via shell commands. Each browser tool call translates to a Python script executed inside the sandbox via `sandbox.execute()`.

### Recommended Approach: Script-based browser interaction

Create a small Python script (`/workspace/.browser/browser_helper.py`) that the browser tool writes into the sandbox on first use. The script uses Playwright to perform operations and outputs structured JSON results to stdout.

```text
BrowserTool._execute(request)
    ↓
sandbox.execute(["python3", "/workspace/.browser/browser_helper.py", "--action", "navigate", "--url", "..."])
    ↓
stdout: {"status": "ok", "title": "...", "url": "..."}
```

This keeps the tool layer clean and all browser execution inside the sandbox.

## Browser Tool Interfaces

```python
# src/control_plane/tools/browser.py

class BrowserNavigateTool(Tool):
    """Navigate to a URL and return page metadata."""
    capability = "browser.navigate"
    required_args = {"url"}
    # Returns: title, url, status_code

class BrowserClickTool(Tool):
    """Click an element identified by CSS selector."""
    capability = "browser.interact"
    required_args = {"selector"}
    # Returns: success, selector, page_url after click

class BrowserTypeTool(Tool):
    """Type text into an element identified by CSS selector."""
    capability = "browser.interact"
    required_args = {"selector", "text"}
    # Returns: success, selector

class BrowserExtractTool(Tool):
    """Extract text content from the page or a specific selector."""
    capability = "browser.read"
    required_args = {}  # optional: selector, max_length
    # Returns: content (bounded), url, truncated

class BrowserDownloadTool(Tool):
    """Download a file from a URL to /downloads."""
    capability = "browser.download"
    required_args = {"url"}  # optional: filename
    # Returns: path, size_bytes
```

All browser tools receive `Sandbox` via constructor injection, same pattern as M4 tools.

## Browser Observations

Browser tools return structured JSON, never raw HTML dumps. The `BrowserExtractTool` must:

- Limit extracted text to a configurable maximum (default 50KB)
- Report truncation
- Extract text content, not raw HTML
- Optionally scope extraction to a CSS selector

## Downloads

Downloads go to `/downloads` inside the sandbox. This is already a standard sandbox directory. Downloads never leave the container.

The `BrowserDownloadTool` uses `wget` or `curl` inside the sandbox (simpler than Playwright downloads for the MVP):

```python
sandbox.execute(["wget", "-O", f"/downloads/{filename}", url], timeout_seconds=60)
```

## Resource Limits

| Resource | Limit | Mechanism |
|----------|-------|-----------|
| Navigation timeout | 30 seconds | Playwright timeout or `timeout` command |
| Action timeout | 15 seconds | Playwright timeout |
| Page text extraction | 50KB | Truncation in browser_helper script |
| Download size | 100MB | Checked after download via `stat` |
| Browser process cleanup | On sandbox destroy | Container removal kills all processes |

## Docker Image for Browser

M5 requires either:

**Option A (recommended)**: A `Dockerfile` that installs Python3, pip, Playwright, and Chromium:

```dockerfile
FROM ubuntu:22.04
RUN apt-get update && apt-get install -y python3 python3-pip wget curl && \
    pip3 install playwright && \
    playwright install chromium && \
    playwright install-deps && \
    apt-get clean
```

Build once: `docker build -t control-plane-sandbox:latest .`

Update `DockerSandbox` default image to `control-plane-sandbox:latest`.

**Option B (simpler, MVP-appropriate)**: Skip Playwright entirely. Use `wget`/`curl` for downloads and a lightweight approach for page interaction. This limits browser capability but avoids image complexity.

The implementation agent should use Option A if Docker build time is acceptable, Option B if minimizing complexity is preferred. Document the choice.

## Testing

### Unit Tests (`tests/unit/test_browser_tool.py`)
Using FakeSandbox:
- Navigate returns structured page metadata
- Click returns success/failure
- Type returns success/failure
- Extract returns bounded text content
- Download returns path and size
- URL validation (reject non-http schemes)
- Timeout handling

### Integration Tests (`tests/integration/test_browser_docker.py`)
Require Docker with browser-capable image:
- Navigate to a controlled test page (use Python's `http.server` inside the sandbox or a well-known stable URL)
- Download a file, verify it exists in `/downloads`
- Extract page content, verify bounded
- Navigation timeout for unreachable URL
- Browser cleanup after sandbox destroy

### Controlled Test Pages
Create a simple HTML file that the test writes into `/workspace` and serves via Python's `http.server` inside the sandbox:

```python
# Write test page to sandbox
sandbox.execute(["sh", "-c", "echo '<html><body><h1>Test</h1><p>Content</p></body></html>' > /workspace/test.html"])
# Start simple server in background
sandbox.execute(["sh", "-c", "cd /workspace && python3 -m http.server 8080 &"])
# Navigate to it
# ... browser tool calls against http://localhost:8080/test.html
```

## Completion Criteria

```
[ ] Browser-capable Docker image built or browser tools work with basic image
[ ] BrowserNavigateTool implemented
[ ] BrowserClickTool implemented
[ ] BrowserTypeTool implemented
[ ] BrowserExtractTool implemented
[ ] BrowserDownloadTool implemented
[ ] All browser tools use Sandbox interface
[ ] All browser tools go through ToolDispatcher
[ ] Downloads stay inside /downloads in sandbox
[ ] Page extraction is bounded
[ ] Unit tests pass with FakeSandbox
[ ] Integration tests pass with Docker
[ ] No M6+ functionality introduced
```

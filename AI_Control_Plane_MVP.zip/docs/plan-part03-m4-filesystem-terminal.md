# Part III — M4: Filesystem + Terminal Tools

## Problem

The control plane has a sandbox (M3) and a tool framework (M2), but no actual computer capabilities. M4 bridges the gap by implementing the first real tools that operate inside the Docker sandbox.

## Requirements

### Filesystem Tools

| Tool | Capability | Arguments | Returns |
|------|-----------|-----------|---------|
| `list_directory` | `filesystem.read` | `path: str` | list of entries with name, type, size |
| `read_file` | `filesystem.read` | `path: str`, `max_bytes: int` (optional, default 1MB) | file content string, truncated flag |
| `write_file` | `filesystem.write` | `path: str`, `content: str` | bytes_written, path |
| `move_file` | `filesystem.write` | `source: str`, `destination: str` | success, source, destination |
| `delete_file` | `filesystem.delete` | `path: str` | success, path |

### Terminal Tools

| Tool | Capability | Arguments | Returns |
|------|-----------|-----------|---------|
| `execute_command` | `terminal.execute` | `command: str`, `timeout_seconds: int` (optional, default 30), `working_directory: str` (optional, default `/workspace`) | exit_code, stdout, stderr, timed_out, output_truncated |

No `get_process_output` yet — that implies long-running process tracking which is not needed at M4 scope. If Gemini believes it's trivially small, it may add it, but it is not required.

## Interfaces

### Filesystem Tool Implementation

```python
# src/control_plane/tools/filesystem.py

class ListDirectoryTool(Tool):
    def __init__(self, sandbox: Sandbox) -> None: ...
    @property
    def metadata(self) -> ToolMetadata: ...
    def _execute(self, request: ToolRequest) -> ToolResult: ...

class ReadFileTool(Tool):
    def __init__(self, sandbox: Sandbox) -> None: ...

class WriteFileTool(Tool):
    def __init__(self, sandbox: Sandbox) -> None: ...

class MoveFileTool(Tool):
    def __init__(self, sandbox: Sandbox) -> None: ...

class DeleteFileTool(Tool):
    def __init__(self, sandbox: Sandbox) -> None: ...
```

### Terminal Tool Implementation

```python
# src/control_plane/tools/terminal.py

class ExecuteCommandTool(Tool):
    def __init__(self, sandbox: Sandbox) -> None: ...
    @property
    def metadata(self) -> ToolMetadata: ...
    def _execute(self, request: ToolRequest) -> ToolResult: ...
```

## Sandbox Integration

Every tool receives a `Sandbox` instance via constructor injection. Tools call **only** `sandbox.execute(command, timeout, max_output_bytes)`. They never import Docker.

### Filesystem tool → Sandbox mapping

| Tool | Sandbox command |
|------|----------------|
| `list_directory` | `sandbox.execute(["ls", "-la", path], ...)` then parse output |
| `read_file` | `sandbox.execute(["cat", path], ..., max_output_bytes=max_bytes)` |
| `write_file` | `sandbox.execute(["sh", "-c", f"cat > {path}"], ...)` using stdin, OR `sandbox.execute(["sh", "-c", f"printf '%s' '{escaped_content}' > {path}"], ...)` |
| `move_file` | `sandbox.execute(["mv", source, destination], ...)` |
| `delete_file` | `sandbox.execute(["rm", path], ...)` |

For `write_file`, the recommended approach is to use a shell heredoc or base64-encode the content and decode inside the sandbox, to handle arbitrary content safely:

```python
import base64
encoded = base64.b64encode(content.encode("utf-8")).decode("ascii")
sandbox.execute(["sh", "-c", f"echo {encoded} | base64 -d > {path}"], ...)
```

### Terminal tool → Sandbox mapping

```python
sandbox.execute(
    ["sh", "-c", f"cd {working_directory} && {command}"],
    timeout_seconds=timeout,
    max_output_bytes=max_output_bytes,
)
```

## Security — Path Validation

All filesystem tools MUST validate paths before execution:

1. **Allowed root directories**: `/workspace`, `/downloads`, `/input`, `/output`, `/temp`
2. **Path normalization**: Use `posixpath.normpath()` to resolve `..` segments
3. **Traversal prevention**: After normalization, verify the path starts with an allowed prefix
4. **Absolute paths only**: Reject relative paths or convert them to absolute under `/workspace`
5. **No host paths**: Reject anything resembling a Windows path (`C:\`, `\\`, drive letters)

Create a shared validation function:

```python
# In filesystem.py or a small shared utility

ALLOWED_ROOTS = ("/workspace", "/downloads", "/input", "/output", "/temp")

def validate_sandbox_path(path: str) -> str:
    """Normalize and validate a path is within sandbox boundaries.
    
    Returns the normalized absolute path.
    Raises ValueError if the path escapes sandbox boundaries.
    """
    import posixpath
    
    if not path or not isinstance(path, str):
        raise ValueError("path must be a non-empty string")
    
    # Reject Windows-style paths
    if "\\" in path or (len(path) >= 2 and path[1] == ":"):
        raise ValueError(f"Windows paths are not allowed: {path}")
    
    # Make absolute under /workspace if relative
    if not path.startswith("/"):
        path = posixpath.join("/workspace", path)
    
    # Normalize to resolve .. and .
    normalized = posixpath.normpath(path)
    
    # Check against allowed roots
    if not any(normalized == root or normalized.startswith(root + "/") for root in ALLOWED_ROOTS):
        raise ValueError(f"path is outside sandbox boundaries: {normalized}")
    
    return normalized
```

Terminal tool `working_directory` argument must also pass this validation.

The `command` string for `execute_command` is intentionally allowed to be arbitrary shell input — the sandbox itself is the security boundary. However, the command runs inside Docker, never on the host.

## Policy Integration

All tools use the existing dispatcher flow. No bypass.

The `AllowListedPolicyGate` already supports capability-based allow listing. For M4 testing:

```python
AllowListedPolicyGate(frozenset({
    "filesystem.read",
    "filesystem.write",
    "filesystem.delete",
    "terminal.execute",
}))
```

M8 will later add fine-grained ALLOW/APPROVE/BLOCK rules per capability.

## Error Model

Tools return structured `ToolResult.failure()` for all errors. Never raise exceptions through the dispatcher.

| Error | Code | Status |
|-------|------|--------|
| Path outside sandbox | `invalid_path` | INVALID_REQUEST |
| File not found | `file_not_found` | FAILURE |
| Directory not found | `directory_not_found` | FAILURE |
| Permission denied | `permission_denied` | FAILURE |
| Command timed out | `timeout` | FAILURE |
| Command failed | `command_failed` | FAILURE |
| Sandbox error | `sandbox_error` | FAILURE |
| Write too large | `content_too_large` | INVALID_REQUEST |

Detect errors by inspecting `SandboxResult.exit_code` and `stderr` content.

## Tests

### Unit Tests (`tests/unit/test_filesystem_tool.py`)

Use a fake `Sandbox` implementation that returns predetermined `SandboxResult` values:

```python
class FakeSandbox(Sandbox):
    """Test double that returns preconfigured results."""
    def __init__(self, results: list[SandboxResult]): ...
    def execute(self, command, timeout, max_output_bytes=1048576): 
        return self._results.pop(0)
    # ... stub lifecycle methods
```

Test:
- `list_directory` parses `ls -la` output correctly
- `read_file` returns file content from sandbox stdout
- `write_file` constructs correct sandbox command
- `move_file` constructs correct sandbox command
- `delete_file` constructs correct sandbox command
- Path validation rejects `../../etc/passwd`
- Path validation rejects `C:\Windows\System32`
- Path validation rejects `/etc/shadow`
- Path validation accepts `/workspace/file.txt`
- Path validation converts relative paths to `/workspace/...`
- Failed sandbox result → structured ToolResult failure

### Unit Tests (`tests/unit/test_terminal_tool.py`)

- `execute_command` returns structured result with exit_code, stdout, stderr
- Working directory validation
- Timeout propagation
- Failed command → structured failure result

### Integration Tests (`tests/integration/test_filesystem_docker.py`)

Require Docker. Test against real sandbox:
- Write a file, read it back, verify content matches
- List directory, verify written file appears
- Move file, verify old path gone and new path exists
- Delete file, verify gone
- Path traversal attempt fails with structured error
- Read nonexistent file fails with structured error

### Integration Tests (`tests/integration/test_terminal_docker.py`)

Require Docker:
- Execute `echo hello`, verify stdout
- Execute failing command, verify exit code and stderr
- Execute with timeout, verify timed_out flag
- Execute in specific working directory
- Execute multi-command pipeline

## Manual Validation

1. Create a sandbox, start it
2. Use `WriteFileTool` to write `/workspace/test.txt`
3. Use `ReadFileTool` to read it back
4. Use `ExecuteCommandTool` to run `cat /workspace/test.txt`
5. Verify no file appears on host
6. Destroy sandbox, verify files gone

## Completion Criteria

```
[ ] ListDirectoryTool implemented and tested
[ ] ReadFileTool implemented and tested
[ ] WriteFileTool implemented and tested
[ ] MoveFileTool implemented and tested
[ ] DeleteFileTool implemented and tested
[ ] ExecuteCommandTool implemented and tested
[ ] All tools use Sandbox interface (not Docker directly)
[ ] All tools go through ToolDispatcher
[ ] Path validation prevents sandbox escape
[ ] Host paths rejected
[ ] FakeSandbox created for unit tests
[ ] Unit tests pass
[ ] Integration tests pass (Docker required)
[ ] No M5+ functionality introduced
```

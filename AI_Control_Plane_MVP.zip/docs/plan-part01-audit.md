# Part I — Current Architecture Audit

## Existing Modules

### `src/control_plane/domain/` — Domain Models

- **Responsibility**: Stable typed value objects. Zero I/O, zero provider/sandbox imports.
- **Key types**:
  - `TaskState(Enum)`: PENDING, RUNNING, COMPLETED, FAILED, CANCELLED
  - `PlanStep`, `Plan`: Descriptive plan structures (no execution authority)
  - `ActionRequest`, `ActionRecord`: Structured action recording
  - `ToolRequest`: Carries tool_name, capability, arguments, request_id
  - `ToolResult`: Carries request_id, status (`ToolResultStatus`), output dict, optional `ToolError`
  - `ToolResultStatus(Enum)`: SUCCESS, FAILURE, BLOCKED, INVALID_REQUEST
  - `ToolError`: Machine-readable code + message
  - `Observation`: Structured fact with source, content, data dict, timestamp
  - `Task`: Canonical state — task_id, goal, state, timestamps, plan, actions list, observations list
- **Depends on**: Python stdlib only
- **Must NOT own**: I/O, Docker, provider objects, policy decisions

### `src/control_plane/runtime/` — Task Runtime

- **Responsibility**: In-memory canonical task state, deterministic lifecycle transitions
- **Key types**:
  - `TaskRuntime`: create_task, get_task, transition_task, record_action, record_observation
  - `TaskNotFoundError(KeyError)`, `InvalidTaskTransition(ValueError)`
  - `_ALLOWED_TRANSITIONS`: PENDING→{RUNNING,CANCELLED}, RUNNING→{COMPLETED,FAILED,CANCELLED}, terminal states→∅
- **Depends on**: `domain` only
- **Must NOT own**: Tool execution, policy decisions, LLM interaction, sandbox operations
- **Notable behavior**: All returned tasks are `deepcopy` snapshots. Mutations only through runtime methods.

### `src/control_plane/tools/` — Tool Framework

- **Key types**:
  - `Tool(ABC)`: Abstract base with `metadata` property and protected `_execute(request) -> ToolResult`
  - `ToolMetadata(frozen dataclass)`: name, description, capability, input_schema
  - `ToolInputSchema(frozen dataclass)`: required_arguments as `frozenset[str]`
  - `ToolRegistry`: Stores tools, exposes metadata publicly, resolves implementations only via `_resolve` (used by dispatcher)
  - `ToolDispatcher`: The single authorized execution path. Validates request → evaluates policy → resolves tool → validates schema → calls `_execute` → validates result → returns deepcopy
  - `DuplicateToolError`, `ToolNotFoundError`
- **Depends on**: `domain`, `policy`
- **Must NOT own**: Task lifecycle, LLM interaction, sandbox implementation

### `src/control_plane/policy/` — Policy Gate

- **Key types**:
  - `PolicyDecision(Enum)`: Currently ALLOW, BLOCK (M8 adds APPROVE)
  - `PolicyResult(frozen dataclass)`: decision + reason string
  - `PolicyGate(Protocol)`: `evaluate(request: ToolRequest) -> PolicyResult`
  - `AllowListedPolicyGate`: Allows only explicitly configured capabilities
- **Depends on**: `domain` only
- **Must NOT own**: Tool execution, LLM judgment, approval workflow

### `src/control_plane/sandbox/` — Sandbox Boundary

- **Key types**:
  - `SandboxState(Enum)`: CREATED, RUNNING, STOPPED, DESTROYED
  - `SandboxResult(dataclass)`: exit_code, stdout, stderr, timed_out, output_truncated
  - `SandboxError(Exception)`: Base sandbox exception
  - `Sandbox(ABC)`: id property, start, stop, destroy, inspect, execute(command, timeout_seconds, max_output_bytes)
  - `DockerSandbox(Sandbox)`: Concrete Docker implementation
- **Depends on**: `contracts` (abstract); `docker` SDK (only inside `docker_sandbox.py`)
- **Must NOT own**: Tool definitions, policy, task state, LLM

## Existing Execution Flow (M2 Dispatcher)

```text
caller provides ToolRequest
    ↓
ToolDispatcher.dispatch(request)
    ↓
_validate_request(request)          → INVALID_REQUEST if malformed
    ↓
PolicyGate.evaluate(request)        → BLOCKED if not allowed
    ↓
ToolRegistry._resolve(tool_name)    → FAILURE if unknown tool
    ↓
capability match check              → INVALID_REQUEST if mismatch
    ↓
_validate_input_schema(request)     → INVALID_REQUEST if missing args
    ↓
tool._execute(deepcopy(request))    → FAILURE if exception thrown
    ↓
validate result type and request_id → FAILURE if invalid
    ↓
return deepcopy(result)
```

All exceptions from tool execution are caught and converted to structured `ToolResult.failure()`.

## Existing Sandbox Flow (M3)

```text
DockerSandbox.__init__(image)
    ↓
docker.from_env() → pull image if missing → containers.create(...)
    ↓
sandbox.start()
    ↓
container.start() → mkdir -p /workspace /downloads /input /output /temp
    ↓
sandbox.execute(command, timeout, max_output_bytes)
    ↓
exec_create → exec_start(stream=True, demux=True) → bounded chunk reading → exec_inspect
    ↓
SandboxResult(exit_code, stdout, stderr, timed_out, output_truncated)
    ↓
sandbox.stop() → container.stop()
    ↓
sandbox.destroy() → container.remove(force=True) → client.close()
```

Container configuration: `volumes=None` (no host mounts), `network_mode="bridge"`, `working_dir="/workspace"`.

## Existing State Model

Current `TaskState` lifecycle:
```text
PENDING → RUNNING → COMPLETED
PENDING → RUNNING → FAILED
PENDING → RUNNING → CANCELLED
PENDING → CANCELLED
```

For M7, this needs extension. New states required: PLANNING, WAITING_FOR_APPROVAL, VERIFYING. See Part VI for exact design.

## Existing Tests

### Unit Tests (`tests/unit/`)
- `test_task_runtime.py` (5 tests): create, valid transitions, invalid transitions, action recording, observation recording
- `test_tool_framework.py` (7 tests): registry, duplicate registration, unknown tool, dispatcher execution, blocked request, capability mismatch, malformed request, schema validation, tool failure handling
- `fake_tools.py`: `RecordingTool` (echoes value), `FailingTool` (raises RuntimeError)

### Integration Tests (`tests/integration/`)
- `test_docker_sandbox.py` (8 tests): lifecycle, workspace directories, isolation (no host mounts + file leak check), execution success/failure/timeout/truncation, invalid lifecycle operations
- Docker availability guard with `pytest.mark.skipif`

## Architectural Gaps for M4–M10

1. **Tools have no sandbox reference**: The `Tool._execute` method receives only a `ToolRequest`. M4 tools need access to a `Sandbox` instance. This requires either passing sandbox via constructor injection or adding an execution context parameter. Constructor injection is cleaner and preserves the existing interface.

2. **TaskState needs expansion**: Current states don't cover PLANNING, WAITING_FOR_APPROVAL, VERIFYING. M7/M8 will extend the enum and transition table.

3. **PolicyDecision needs APPROVE**: Currently only ALLOW/BLOCK. M8 adds APPROVE and the approval workflow.

4. **No LLM layer exists**: M6 creates it from scratch.

5. **No agent loop exists**: M7 creates it from scratch.

6. **No verification/tracing/evaluation**: M9/M10 create these from scratch.

## M3 Stabilization Status

The M3 review fixes have already been applied:
- Output bounding is implemented via streaming chunk reader with `max_output_bytes` and `output_truncated` flag
- Isolation test checks both `HostConfig.Binds` and verifies files don't leak to host project directory or host `/workspace` path
- All 23 tests pass (15 unit + 8 integration)

**No M3 stabilization step is required before M4.**

# Part VIII — M9: Verification, Recovery, and Checkpointing

## Problem

The agent cannot declare success solely from its own narration. M9 adds evidence-based verification, failure classification, recovery strategies, and task persistence.

## Verification

### Interface

```python
# src/control_plane/verification/contracts.py

class VerificationStatus(str, Enum):
    VERIFIED = "verified"
    FAILED = "failed"
    INCONCLUSIVE = "inconclusive"

@dataclass
class VerificationResult:
    status: VerificationStatus
    evidence: list[str]  # human-readable evidence items
    reason: str

class VerificationCheck(Protocol):
    """A single verification check against sandbox state."""
    def verify(self, sandbox: Sandbox, criteria: dict[str, Any]) -> VerificationResult: ...
```

### Concrete Checks

```python
# src/control_plane/verification/checks.py

class FileExistsCheck:
    """Verify a file exists at a specified path inside the sandbox."""
    def verify(self, sandbox, criteria):
        path = criteria["path"]
        result = sandbox.execute(["test", "-f", path], timeout_seconds=5)
        if result.exit_code == 0:
            return VerificationResult(VERIFIED, [f"file exists: {path}"], "file found")
        return VerificationResult(FAILED, [f"file missing: {path}"], "file not found")

class FileContentCheck:
    """Verify a file contains expected content."""
    def verify(self, sandbox, criteria):
        path = criteria["path"]
        expected = criteria.get("contains")
        result = sandbox.execute(["cat", path], timeout_seconds=5, max_output_bytes=65536)
        if expected and expected in result.stdout:
            return VerificationResult(VERIFIED, [...], "content matches")
        return VerificationResult(FAILED, [...], "content mismatch")

class CommandSuccessCheck:
    """Verify a command exits successfully."""
    def verify(self, sandbox, criteria):
        command = criteria["command"]
        result = sandbox.execute(command, timeout_seconds=criteria.get("timeout", 10))
        if result.exit_code == 0:
            return VerificationResult(VERIFIED, [...], "command succeeded")
        return VerificationResult(FAILED, [...], f"exit code {result.exit_code}")

class FileDownloadedCheck:
    """Verify a file was downloaded to /downloads."""
    # Similar to FileExistsCheck but scoped to /downloads
```

### Verification in the Agent Loop

When the LLM proposes COMPLETE, the runtime:

1. Transitions to VERIFYING
2. Runs applicable verification checks
3. If all VERIFIED → COMPLETED
4. If any FAILED → transitions back to RUNNING, informs LLM via error_context, attempts recovery
5. If INCONCLUSIVE → transitions to COMPLETED with a note (MVP behavior)

Verification criteria come from the task goal or can be defined explicitly by evaluation tasks (M10).

## Failure Classification

```python
# src/control_plane/domain/models.py (addition)

class FailureCategory(str, Enum):
    TOOL_FAILURE = "tool_failure"          # Tool returned error
    ENVIRONMENT_FAILURE = "environment_failure"  # Sandbox/Docker failure
    TIMEOUT = "timeout"                     # Operation timed out
    INVALID_INPUT = "invalid_input"         # Bad arguments or path
    POLICY_REJECTION = "policy_rejection"   # Blocked by policy
    APPROVAL_REJECTION = "approval_rejection"  # Human rejected
    VERIFICATION_FAILURE = "verification_failure"  # Evidence doesn't match
    ITERATION_LIMIT = "iteration_limit"     # Max iterations exceeded
    LLM_FAILURE = "llm_failure"            # LLM provider error
```

The agent loop classifies each failure and records it in the observation. This helps the LLM understand what went wrong during replanning.

## Recovery Strategies

| Failure Category | Strategy | Max Retries |
|-----------------|----------|-------------|
| TOOL_FAILURE | Retry same action | 2 |
| ENVIRONMENT_FAILURE | Retry after delay | 1 |
| TIMEOUT | Retry with longer timeout | 1 |
| INVALID_INPUT | Replan (LLM must fix input) | 0 |
| POLICY_REJECTION | Inform LLM, choose different approach | 0 |
| APPROVAL_REJECTION | Inform LLM, choose different approach | 0 |
| VERIFICATION_FAILURE | Replan (try alternative approach) | 2 |
| ITERATION_LIMIT | Fail (terminal) | 0 |
| LLM_FAILURE | Retry LLM call | 2 |

Recovery is deterministic and rule-based. The runtime decides recovery, not the LLM.

```python
# src/control_plane/runtime/recovery.py

@dataclass
class RecoveryAction:
    strategy: str  # "retry", "replan", "abort", "request_approval"
    reason: str
    delay_seconds: float = 0.0

def determine_recovery(
    failure: FailureCategory,
    consecutive_failures: int,
    max_retries: int = 2,
) -> RecoveryAction:
    """Deterministic recovery decision based on failure type and history."""
    ...
```

## Checkpointing

### Checkpoint Contents

```python
@dataclass
class TaskCheckpoint:
    task: Task  # full canonical task state
    plan: Plan | None
    action_history: list[ActionRecord]
    observations: list[Observation]
    iteration_count: int
    consecutive_failures: int
    sandbox_id: str | None  # to know if sandbox needs recreation
    created_at: datetime
```

### Storage Mechanism

Use the simplest justified local persistence: **JSON file on the host filesystem**.

```python
# src/control_plane/runtime/checkpoint.py

class CheckpointStore(Protocol):
    def save(self, task_id: str, checkpoint: TaskCheckpoint) -> None: ...
    def load(self, task_id: str) -> TaskCheckpoint | None: ...
    def delete(self, task_id: str) -> None: ...

class JsonFileCheckpointStore:
    """Stores checkpoints as JSON files in a local directory."""
    
    def __init__(self, checkpoint_dir: str = ".checkpoints") -> None:
        self._dir = Path(checkpoint_dir)
        self._dir.mkdir(exist_ok=True)
    
    def save(self, task_id: str, checkpoint: TaskCheckpoint) -> None:
        path = self._dir / f"{task_id}.json"
        data = _serialize_checkpoint(checkpoint)
        path.write_text(json.dumps(data, indent=2))
    
    def load(self, task_id: str) -> TaskCheckpoint | None:
        path = self._dir / f"{task_id}.json"
        if not path.exists():
            return None
        data = json.loads(path.read_text())
        return _deserialize_checkpoint(data)
    
    def delete(self, task_id: str) -> None:
        path = self._dir / f"{task_id}.json"
        path.unlink(missing_ok=True)
```

Checkpoints are saved on the **host** filesystem (they are control plane state, not agent execution state). This is not a violation of the sandbox rule — the checkpoint is the runtime's own persistence, not agent-accessible data.

### When to Checkpoint

- After every successful tool execution
- Before transitioning to WAITING_FOR_APPROVAL
- After plan changes

### Resume Behavior

```text
Task
 ↓
Action 1 completed (checkpoint saved)
 ↓
Action 2 completed (checkpoint saved)
 ↓
process crash
 ↓
restart
 ↓
load checkpoint
 ↓
recreate sandbox (new container)
 ↓
continue from Action 3
```

On resume:
1. Load checkpoint
2. Restore `TaskRuntime` state from checkpoint
3. Create a new sandbox (the old container is gone)
4. Resume agent loop from the saved iteration count

**Limitation**: Files created in the old sandbox are lost. The agent must re-create them or the task may need to restart from the beginning. This is acceptable for the MVP. Document this limitation.

## Tests

### Unit Tests
- `test_verification.py`: FileExistsCheck, FileContentCheck, CommandSuccessCheck with FakeSandbox
- `test_recovery.py`: determine_recovery returns correct strategy for each failure type
- `test_checkpoint.py`: save/load/delete checkpoint roundtrip, serialization fidelity

### Integration Tests
- Verify file creation inside Docker, then run FileExistsCheck against real sandbox
- Interrupt a task (simulate crash), resume from checkpoint, verify loop continues
- Verify checkpoint is deleted after task completion

## Completion Criteria

```
[ ] VerificationCheck protocol defined
[ ] FileExistsCheck, FileContentCheck, CommandSuccessCheck implemented
[ ] Verification integrated into agent loop (VERIFYING state)
[ ] FailureCategory enum defined
[ ] Recovery strategy function implemented
[ ] Recovery integrated into agent loop
[ ] CheckpointStore protocol defined
[ ] JsonFileCheckpointStore implemented
[ ] Checkpoint save/load/delete works
[ ] Agent loop saves checkpoints
[ ] Agent loop resumes from checkpoints
[ ] Resume limitation documented (sandbox state is lost)
[ ] Unit tests pass
[ ] Integration tests pass
[ ] No M10+ functionality introduced
```

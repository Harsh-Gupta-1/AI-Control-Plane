# Part II — Global M4–M10 Target Architecture

## Final Module Structure After M10

```text
src/control_plane/
    __init__.py
    domain/
        __init__.py
        models.py                  # Extended with new states, approval, verification models
    runtime/
        __init__.py
        task_runtime.py            # Extended with new states and agent loop coordination
    tools/
        __init__.py
        contracts.py               # Unchanged Tool ABC
        registry.py                # Unchanged
        dispatcher.py              # Extended to handle APPROVE decision
        filesystem.py              # M4: filesystem tool implementations
        terminal.py                # M4: terminal tool implementation
        browser.py                 # M5: browser tool implementation
    policy/
        __init__.py
        gate.py                    # Extended: ALLOW/APPROVE/BLOCK, capability rules
    approval/
        __init__.py
        contracts.py               # M8: approval request/resolution interface
        in_memory.py               # M8: in-memory approval store
    sandbox/
        __init__.py
        contracts.py               # Unchanged Sandbox ABC
        docker_sandbox.py          # Unchanged DockerSandbox
    llm/
        __init__.py
        contracts.py               # M6: LLMProvider protocol, proposal models
        fake_provider.py           # M6: deterministic fake for testing
        ollama_provider.py         # M6: local Ollama adapter
    verification/
        __init__.py
        contracts.py               # M9: verification interface
        checks.py                  # M9: concrete verification checks
    tracing/
        __init__.py
        contracts.py               # M10: trace event models and sink interface
        json_sink.py               # M10: JSON-lines file trace sink
    evaluation/
        __init__.py
        runner.py                  # M10: controlled task suite runner
        tasks.py                   # M10: task definitions
tests/
    __init__.py
    unit/
        __init__.py
        fake_tools.py              # Extended with sandbox-aware fakes
        test_task_runtime.py       # Extended with new states
        test_tool_framework.py     # Unchanged
        test_filesystem_tool.py    # M4
        test_terminal_tool.py      # M4
        test_browser_tool.py       # M5
        test_llm_contracts.py      # M6
        test_agent_loop.py         # M7
        test_policy_rules.py       # M8
        test_approval.py           # M8
        test_verification.py       # M9
        test_tracing.py            # M10
    integration/
        __init__.py
        test_docker_sandbox.py     # Unchanged
        test_filesystem_docker.py  # M4
        test_terminal_docker.py    # M4
        test_browser_docker.py     # M5
        test_ollama_provider.py    # M6
        test_agent_e2e.py          # M7
    evaluation/
        __init__.py
        test_eval_suite.py         # M10
```

## Module Responsibilities and Dependencies

### `domain` — Stable Core Types
- **Owns**: All value objects, enums, dataclasses for task state, actions, tools, observations, policy decisions, approval, verification, trace events
- **Depends on**: Python stdlib only
- **Forbidden deps**: docker, any provider SDK, any tool implementation, sandbox

### `runtime` — Task Lifecycle Coordination
- **Owns**: Canonical task state, lifecycle transitions, agent loop orchestration (M7)
- **Depends on**: `domain`, `tools` (dispatcher), `policy` (gate protocol), `llm` (provider protocol), `approval` (protocol), `verification` (protocol), `tracing` (sink protocol)
- **Forbidden deps**: `docker`, `sandbox.docker_sandbox`, any provider SDK
- **Note**: Runtime depends on *interfaces/protocols* from other modules, never concrete implementations

### `tools` — Tool Framework + Concrete Tools
- **Owns**: Tool ABC, registry, dispatcher, concrete tool implementations (filesystem, terminal, browser)
- **Depends on**: `domain`, `policy` (for dispatcher), `sandbox.contracts` (for tool implementations)
- **Forbidden deps**: `docker`, `sandbox.docker_sandbox`, any provider SDK
- **Critical**: Concrete tools receive a `Sandbox` instance via constructor injection. They call `sandbox.execute()` — never Docker directly.

### `policy` — Authorization Rules
- **Owns**: PolicyDecision enum, PolicyResult, PolicyGate protocol, concrete policy implementations
- **Depends on**: `domain` only
- **Forbidden deps**: Everything else. Policy is deterministic and side-effect-free.

### `approval` — Human Approval Workflow
- **Owns**: Approval request/response models, approval store, resolution
- **Depends on**: `domain` only
- **Forbidden deps**: `tools`, `sandbox`, `llm`

### `sandbox` — Isolation Boundary
- **Owns**: Sandbox ABC, SandboxResult, SandboxState, SandboxError, DockerSandbox
- **Depends on**: `docker` SDK (only inside `docker_sandbox.py`)
- **Forbidden deps**: `domain`, `tools`, `policy`, `runtime`, `llm`

### `llm` — LLM Abstraction
- **Owns**: LLMProvider protocol, proposal/response models, fake provider, concrete adapters
- **Depends on**: `domain` (for proposal/tool-request types)
- **Forbidden deps**: `runtime`, `tools`, `sandbox`, `policy`

### `verification` — Completion Checks
- **Owns**: Verification interface, evidence evaluation, concrete checks
- **Depends on**: `domain`, `sandbox.contracts` (to run verification commands)
- **Forbidden deps**: `docker`, `llm`, `runtime`

### `tracing` — Execution Trace
- **Owns**: Trace event schema, trace sink interface, concrete sinks
- **Depends on**: `domain` only
- **Forbidden deps**: Everything else. Tracing observes but never controls.

### `evaluation` — Controlled Task Suite
- **Owns**: Task definitions, evaluation runner, result reporting
- **Depends on**: `domain`, `runtime` (to drive tasks)
- **Forbidden deps**: `docker`

## Dependency Direction (Final)

```text
domain  ← policy
domain  ← approval
domain  ← verification
domain  ← tracing
domain  ← llm (contracts only)
domain  ← tools.contracts
domain  ← sandbox.contracts

tools.concrete  ← sandbox.contracts (constructor injection)
tools.dispatcher ← policy (protocol)

runtime ← domain
runtime ← tools.dispatcher
runtime ← policy (protocol)
runtime ← llm (protocol)
runtime ← approval (protocol)
runtime ← verification (protocol)
runtime ← tracing (protocol)

sandbox.docker_sandbox ← docker SDK (isolated)
llm.ollama_provider ← httpx/requests (isolated)

application/composition root → all concrete implementations
```

The composition root (a future `main.py` or test setup) is the only place that wires concrete implementations together.

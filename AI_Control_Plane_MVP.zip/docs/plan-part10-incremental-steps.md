# Part X — Incremental Implementation Steps

Every step below is small enough for an implementation agent to complete safely in one sitting.

---

## M4 — Filesystem + Terminal Tools

### M4.1 — FakeSandbox and Path Validation

**Objective**: Create a test double for Sandbox and the shared path validation utility.

**Files to create**:
- `tests/unit/fake_sandbox.py`
- `src/control_plane/tools/path_validation.py`

**Files to modify**: None

**Implementation**:
1. Create `FakeSandbox(Sandbox)` that returns preconfigured `SandboxResult` values from a list. Stub lifecycle methods (start/stop/destroy do nothing, inspect returns RUNNING, id returns "fake-sandbox").
2. Create `validate_sandbox_path(path: str) -> str` function with all validation rules (see Part III).
3. Add unit tests in `tests/unit/test_path_validation.py`.

**Tests**: Path validation: traversal prevention, Windows path rejection, relative-to-absolute conversion, allowed roots.

**Must NOT implement**: Any actual tools yet.

---

### M4.2 — Filesystem Tools (Read + List)

**Objective**: Implement `ListDirectoryTool` and `ReadFileTool`.

**Files to create**:
- `src/control_plane/tools/filesystem.py`
- `tests/unit/test_filesystem_tool.py`

**Files to modify**:
- `src/control_plane/tools/__init__.py` (export new tools)

**Implementation**:
1. `ListDirectoryTool`: validates path → `sandbox.execute(["ls", "-la", path])` → parse output into structured list → return `ToolResult`.
2. `ReadFileTool`: validates path → `sandbox.execute(["cat", path], max_output_bytes=max_bytes)` → return content in `ToolResult.output`.
3. Both receive `Sandbox` via constructor. Both have `ToolMetadata` with appropriate capability.

**Tests**: Unit tests with FakeSandbox. Parse `ls -la` output. Handle missing file. Handle empty directory.

**Must NOT implement**: write, move, delete, terminal.

---

### M4.3 — Filesystem Tools (Write + Move + Delete)

**Objective**: Implement `WriteFileTool`, `MoveFileTool`, `DeleteFileTool`.

**Files to modify**:
- `src/control_plane/tools/filesystem.py`
- `tests/unit/test_filesystem_tool.py`
- `src/control_plane/tools/__init__.py`

**Implementation**:
1. `WriteFileTool`: validates path → base64-encode content → `sandbox.execute(["sh", "-c", f"echo {encoded} | base64 -d > {path}"])` → return bytes written.
2. `MoveFileTool`: validates both paths → `sandbox.execute(["mv", src, dest])` → return success.
3. `DeleteFileTool`: validates path → `sandbox.execute(["rm", path])` → return success.

**Tests**: Unit tests with FakeSandbox. Path validation for all three. Error handling.

**Must NOT implement**: terminal tools.

---

### M4.4 — Terminal Tool

**Objective**: Implement `ExecuteCommandTool`.

**Files to create**:
- `src/control_plane/tools/terminal.py`
- `tests/unit/test_terminal_tool.py`

**Files to modify**:
- `src/control_plane/tools/__init__.py`

**Implementation**:
1. `ExecuteCommandTool`: validates working_directory → `sandbox.execute(["sh", "-c", f"cd {wd} && {command}"], timeout_seconds, max_output_bytes)` → map SandboxResult to ToolResult.

**Tests**: Unit tests with FakeSandbox.

**Must NOT implement**: browser, LLM, agent loop.

---

### M4.5 — Filesystem + Terminal Integration Tests

**Objective**: Verify all M4 tools work against real Docker.

**Files to create**:
- `tests/integration/test_filesystem_docker.py`
- `tests/integration/test_terminal_docker.py`

**Implementation**:
1. Each test creates a DockerSandbox, starts it, registers tools with sandbox, runs tool operations, verifies results.
2. Write → Read roundtrip. List after write. Move then verify. Delete then verify missing.
3. Terminal: echo, failing command, timeout, working directory.
4. Path traversal rejection in real sandbox context.

**Tests**: Docker integration tests. Skip if Docker unavailable.

**Milestone boundary**: After M4.5, run full test suite. Report results. Ask user to commit.

**Commit message**: `feat: implement M4 filesystem and terminal tools with sandbox integration`

---

## M5 — Browser Capability

### M5.1 — Browser Docker Image

**Objective**: Create a Dockerfile for the browser-capable sandbox and update DockerSandbox to use it.

**Files to create**:
- `sandbox/Dockerfile` (project root level)

**Files to modify**:
- `src/control_plane/sandbox/docker_sandbox.py` (update default image)

**Implementation**:
1. Create Dockerfile extending ubuntu:22.04 with python3, pip, wget, curl installed.
2. If Playwright is too heavy for the user's Docker size limit, skip it and use wget/curl only for browser operations. Document the decision.
3. Build the image in tests or provide a build script.

**Tests**: Verify the image builds. Verify python3 is available inside sandbox.

**Must NOT implement**: Browser tools yet.

---

### M5.2 — Browser Tools (Navigate + Extract + Download)

**Objective**: Implement core browser tools.

**Files to create**:
- `src/control_plane/tools/browser.py`
- `tests/unit/test_browser_tool.py`

**Implementation**:
1. `BrowserNavigateTool`: uses `curl -sI {url}` inside sandbox to get headers.
2. `BrowserExtractTool`: uses `curl -s {url}` inside sandbox, extracts text, truncates.
3. `BrowserDownloadTool`: uses `wget -O /downloads/{filename} {url}` inside sandbox.
4. Keep interaction tools (click, type) as stubs or skip if no Playwright — document.

**Tests**: Unit tests with FakeSandbox.

---

### M5.3 — Browser Integration Tests

**Objective**: Test browser tools against real Docker.

**Files to create**:
- `tests/integration/test_browser_docker.py`

**Tests**: Download a file, verify it exists in /downloads. Navigate to a controlled page. Extract content. Timeout handling.

**Milestone boundary**: After M5.3, run full test suite. Ask user to commit.

**Commit message**: `feat: implement M5 browser tools with sandboxed download capability`

---

## M6 — LLM Abstraction

### M6.1 — LLM Contracts and FakeProvider

**Objective**: Define the LLM interface and implement the deterministic fake.

**Files to create**:
- `src/control_plane/llm/__init__.py`
- `src/control_plane/llm/contracts.py`
- `src/control_plane/llm/fake_provider.py`
- `tests/unit/test_llm_contracts.py`

**Implementation**: As specified in Part V. AgentContext, LLMProposal, ProposalAction, LLMProvider protocol, LLMError, FakeLLMProvider.

**Tests**: Fake provider returns proposals in sequence. Exhaustion returns GIVE_UP.

**Must NOT implement**: Ollama adapter yet.

---

### M6.2 — Ollama Provider

**Objective**: Implement the local LLM adapter.

**Files to create**:
- `src/control_plane/llm/ollama_provider.py`
- `tests/integration/test_ollama_provider.py`

**Files to modify**:
- `pyproject.toml` (add `httpx` if used, or use `urllib.request`)

**Implementation**: As specified in Part V. System prompt engineering. JSON parsing. Retry on malformed output. LLMError on provider failure.

**Tests**: Integration test (skip if Ollama unavailable).

**Milestone boundary**: After M6.2, ask user to commit.

**Commit message**: `feat: implement M6 LLM abstraction with fake and Ollama providers`

---

## M7 — Agent Execution Loop

### M7.1 — Extended Task States

**Objective**: Add PLANNING, WAITING_FOR_APPROVAL, VERIFYING states.

**Files to modify**:
- `src/control_plane/domain/models.py`
- `src/control_plane/runtime/task_runtime.py`
- `tests/unit/test_task_runtime.py`

**Implementation**: Add states to enum. Update transition table. Update existing tests.

**Must NOT implement**: Agent loop yet.

---

### M7.2 — Agent Loop Core

**Objective**: Implement the plan-act-observe loop.

**Files to create**:
- `src/control_plane/runtime/agent_loop.py`
- `tests/unit/test_agent_loop.py`

**Files to modify**:
- `src/control_plane/runtime/__init__.py`

**Implementation**: As specified in Part VI. Use FakeLLMProvider + FakeSandbox + RecordingTool for tests.

**Tests**: Simple completion, multi-step, give up, max iterations.

---

### M7.3 — Replanning and Safety Guards

**Objective**: Add replan-on-failure, repeated action detection, context bounding.

**Files to modify**:
- `src/control_plane/runtime/agent_loop.py`
- `tests/unit/test_agent_loop.py`

**Tests**: Replan after consecutive failures. Repeated action detection. Context window bounding.

---

### M7.4 — Agent Loop E2E Integration

**Objective**: Run the agent loop against real Docker with FakeLLM.

**Files to create**:
- `tests/integration/test_agent_e2e.py`

**Tests**: FakeLLM proposes write_file → read_file → COMPLETE. Verify file in sandbox. Verify task COMPLETED.

**Milestone boundary**: After M7.4, ask user to commit.

**Commit message**: `feat: implement M7 agent execution loop with plan-act-observe cycle`

---

## M8 — Full Policy + Human Approval

### M8.1 — Extended Policy Gate

**Objective**: Add APPROVE decision and CapabilityPolicyGate.

**Files to modify**:
- `src/control_plane/policy/gate.py`
- `src/control_plane/policy/__init__.py`
- `tests/unit/test_tool_framework.py` (verify backward compatibility)

**Files to create**:
- `tests/unit/test_policy_rules.py`

---

### M8.2 — Approval Domain Models and Store

**Objective**: Create approval request/decision models and in-memory store.

**Files to create**:
- `src/control_plane/approval/__init__.py`
- `src/control_plane/approval/contracts.py`
- `src/control_plane/approval/in_memory.py`
- `tests/unit/test_approval.py`

**Files to modify**:
- `src/control_plane/domain/models.py` (add ApprovalStatus, ApprovalRequest, ApprovalDecision)

---

### M8.3 — Dispatcher + Loop Approval Integration

**Objective**: Wire approval into dispatcher and agent loop.

**Files to modify**:
- `src/control_plane/tools/dispatcher.py`
- `src/control_plane/runtime/agent_loop.py`
- `tests/unit/test_agent_loop.py`

**Tests**: Approval-required action pauses task. Approved action executes. Rejected action recorded. Negative security tests.

**Milestone boundary**: After M8.3, ask user to commit.

**Commit message**: `feat: implement M8 capability policy rules and human approval workflow`

---

## M9 — Verification, Recovery, Checkpointing

### M9.1 — Verification Checks

**Objective**: Implement verification interface and concrete checks.

**Files to create**:
- `src/control_plane/verification/__init__.py`
- `src/control_plane/verification/contracts.py`
- `src/control_plane/verification/checks.py`
- `tests/unit/test_verification.py`

---

### M9.2 — Failure Classification and Recovery

**Objective**: Add failure categories and deterministic recovery logic.

**Files to create**:
- `src/control_plane/runtime/recovery.py`

**Files to modify**:
- `src/control_plane/domain/models.py` (add FailureCategory)
- `src/control_plane/runtime/agent_loop.py`
- `tests/unit/test_agent_loop.py`

---

### M9.3 — Checkpointing

**Objective**: Implement checkpoint store and integrate with agent loop.

**Files to create**:
- `src/control_plane/runtime/checkpoint.py`
- `tests/unit/test_checkpoint.py`

**Files to modify**:
- `src/control_plane/runtime/agent_loop.py`

**Tests**: Save/load roundtrip. Resume from checkpoint. Delete after completion.

**Milestone boundary**: After M9.3, ask user to commit.

**Commit message**: `feat: implement M9 verification checks, recovery strategies, and checkpointing`

---

## M10 — Tracing + Evaluation

### M10.1 — Trace Events and Sink

**Objective**: Define trace event schema and JSON file sink.

**Files to create**:
- `src/control_plane/tracing/__init__.py`
- `src/control_plane/tracing/contracts.py`
- `src/control_plane/tracing/json_sink.py`
- `tests/unit/test_tracing.py`

**Files to modify**:
- `src/control_plane/runtime/agent_loop.py` (emit trace events)

---

### M10.2 — Evaluation Task Suite

**Objective**: Define evaluation tasks and runner.

**Files to create**:
- `src/control_plane/evaluation/__init__.py`
- `src/control_plane/evaluation/tasks.py`
- `src/control_plane/evaluation/runner.py`
- `tests/evaluation/__init__.py`
- `tests/evaluation/test_eval_suite.py`

---

### M10.3 — Full Evaluation Run

**Objective**: Run the evaluation suite with FakeLLM and verify results.

**Tests**: Run simple tasks, verify pass/fail matches expected. Run safety tasks, verify blocked. Generate trace files, verify readable.

**Milestone boundary**: After M10.3, ask user to commit.

**Commit message**: `feat: implement M10 execution tracing and controlled evaluation suite`
